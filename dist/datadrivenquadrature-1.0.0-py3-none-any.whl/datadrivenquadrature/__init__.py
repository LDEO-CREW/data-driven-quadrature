# __init__.py
from .main import check_params, flatten_history, find_normalization_vector, optimize